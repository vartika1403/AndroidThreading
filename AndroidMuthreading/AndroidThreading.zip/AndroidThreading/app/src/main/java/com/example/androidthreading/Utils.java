package com.example.androidthreading;

public class Utils {
}
